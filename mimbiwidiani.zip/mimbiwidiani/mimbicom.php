<table> 
    <tr>
        <th>id_kelas</th>
        <th>nama_kelas</th>
         <th>kopetensi</th>
        <th>tahun_pelajaran</th>
        <th>keterangan</th>

    </tr>
</table>
<?php
include 'mimbi.php';
$biodata=mysqli_query($mimbi,"select * from biodata");
while($widiani = mysqli_fetch_array ($biodata)){ 

     echo"
     <tr>
     <td>$widiani[id_kelas]</td> 
      <td>$widiani[kompetensi]</td>
      <td>$widiani[tahun_pelajaran]</td>
      <td>$widiani[keterangan]</td>
      </tr>
     ";
}
        ?>