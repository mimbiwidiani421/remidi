</style>
<body> class="bd"
 <form methpod="POST" enctype=multipart/form-data" class="box"> 
      <h2>useername</h2>
      <input type="text" name="user" placeholder="username">
      <h2>password</h2>
      <input type="password" name="pass" placeholder="password">
      <br></br>
      <input type
 </form>
</body>
<?php 
include'mimbi.php';
if (isset($_POST[konfirmasi])){
    
}